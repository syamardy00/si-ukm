@extends('monitoring.index')
@section('content')
  @include('public.beritaUkm.show')
@endsection
