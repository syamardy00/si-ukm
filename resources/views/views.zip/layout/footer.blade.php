<footer class="main-footer">
  <div class="pull-right hidden-xs">
    Sistem Informasi UKM - <b>Version</b> 1.0
  </div>
  <strong>Copyright &copy; 2019 Syam Ardy | Teknik Informatika | Politeknik TEDC Bandung.</strong> All rights
  reserved.
</footer>
<!-- <div style="clear:both"></div>
<footer class="main-footer col-md-12" style="background:#1A2226; color:white; width:100%; left:0; margin-left:0px;">
  <div class="col-md-3" style="border-right:2px solid #3C8DBC; text-align:center; margin-top:5px;">
      <img src="{{url('/foto/footer.png')}}" class="col-md-7" style="text-align:center; position:center;">
  </div>

  <div class="col-md-6" style="text-align:center; margin-top:5px; padding-bottom:10px;">
    <h3>Sistem Informasi Unit Kegiatan Mahasiswa</h3>
    <hr>
    Copyright &copy; 2019 Syam Ardy | Teknik Informatika | Politeknik TEDC Bandung. All rights reserved.
  </div>

  <div class="col-md-3" style="text-align:right; border-left:2px solid #3C8DBC; margin-top:5px;">
    <b style="color:#3C8DBC">Politeknik TEDC Bandung</b><br>
    Jl. Politeknik - Pasantren Km 2<br>
    Cibabat - Cimahi Utara<br>
    Kota Cimahi - Indonesia<br>
    Kode Pos 40513<br>
    Telepon +6222-6645951<br>
    Email info@poltektedc.ac.id
  </div>

</footer> -->
