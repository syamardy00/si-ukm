@extends('anggotaUkm.index')
@section('content')
  @include('public.beritaUkm.show')
@endsection
