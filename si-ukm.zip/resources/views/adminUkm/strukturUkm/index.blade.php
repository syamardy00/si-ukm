@extends('adminUkm.index')
@section('content')

  <section class="content-header">
  <h1>
    Struktur Pengurus Ukm
    <!-- <small>Lihat Profil UKM</small> -->
  </h1>
  <ol class="breadcrumb">
    <li class="active"><a href="{{route('strukturUkm.index')}}"><i class="fa fa-user"></i>Struktur Pengurus Ukm</a></li>
    <!-- <li class="active">Kelola Anggota Ukm</li> -->
  </ol>
  </section>

  <section class="content">
    <div class="row">



    </div>
  </section>

@endsection
