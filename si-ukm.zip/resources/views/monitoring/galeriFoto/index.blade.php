@extends('monitoring.index')
@section('content')
  @include('public.galeriFoto.index')
@endsection
