@extends('monitoring.index')
@section('content')
  @include('public.calonAnggota.show')
@endsection
