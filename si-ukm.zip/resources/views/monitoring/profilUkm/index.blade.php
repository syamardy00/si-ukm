@extends('monitoring.index')
@section('content')
  @include('public.profilUkm.index')
@endsection
