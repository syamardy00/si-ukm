<footer class="main-footer">
  <div class="pull-right hidden-xs">
    Sistem Informasi UKM - <b>Version</b> 1.0
  </div>
  <strong>Copyright &copy; 2019 Syam Ardy | Teknik Informatika | Politeknik TEDC Bandung.</strong> All rights
  reserved.
</footer>
