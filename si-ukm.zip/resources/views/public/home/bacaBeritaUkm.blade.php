@extends('public.index')
@section('content')
  @include('public.beritaUkm.show')
@endsection
