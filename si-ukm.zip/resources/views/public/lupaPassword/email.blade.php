<center>
<div style="background:#222D32; color:white; padding:5px; border-bottom:5px solid #0097BC; margin-bottom:-13px;">
<h1>Sistem Informasi Unit Kegiatan Mahasiswa</h1>
<h2>Politeknik TEDC Bandung</h2>
</div>
</center>
<br>
<div style="background:#222D32; color:white; padding:5px; border-bottom:5px solid #0097BC;">
  Reset Password
</div>
<hr><br>

<table>
  <tr>
    <td style="vertical-align:top;" colspan="2">Hello, {{$nama}}. <br>Berikut adalah password baru anda untuk mengakses Sistem
    Informasi Unit Kegiatan Mahasiswa Politeknik TEDC Bandung.</td>
  </tr>
  <tr>
    <td style="width:100px; vertical-align:top;"><b>Username </b></td> <td style="width:300px;">: {{$username}}</td>
  </tr>
  <tr>
    <td style="width:100px; vertical-align:top;"><b>Password Baru </b></td> <td style="width:300px;">: {{$password_baru}}</td>
  </tr>
  <tr>
    <td style="width:300px; vertical-align:top;" colspan="2"><br>Silahkan login dengan password baru diatas, kemudian silahkan ganti password anda.</td>
  </tr>
</table>
<br>
<hr>
Sistem Informasi UKM - <b>Version</b> 1.0

  <strong>Copyright &copy; 2019 Syam Ardy | Teknik Informatika | Politeknik TEDC Bandung.</strong> All rights
  reserved.
