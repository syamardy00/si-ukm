<!DOCTYPE html>
<html>
<head>
<?php echo $__env->make('layout.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>
<body class="hold-transition skin-blue sidebar-mini">
  <!-- loading -->
  <div class="preloader">
    <div class="loading">
      <img src="<?php echo e(url('/foto/loading.gif')); ?>" width="400">
      <p><b>Harap Tunggu</b></p>
    </div>
  </div>
  <!-- end loading -->
  <div class="wrapper">

    <!-- sesuaikan -->
    <?php echo $__env->make('anggotaUkm.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('anggotaUkm.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

      <div class="content-wrapper">

        <?php if($profil[0]->email == ''): ?>
        <br>
          <div class="col-md-12">
            <div class="alert alert-warning alert-dismissible" style="border-left:10px solid #C87F0A;"> 
              <h4><i class="icon fa fa-info"></i> Penting !</h4>
              Lengkapi profil anda, segera ganti <b>Password</b> yang diberikan oleh Admin UKM,
              Tambahkan <b>Email Aktif</b> untuk mempermudah proses jika terjadi lupa password. Klik menu <b>Profil Saya</b>.
            </div>
          </div>
        <div style="clear:both; margin-bottom:-20px;"></div>
        <?php endif; ?>
        <?php echo $__env->yieldContent('content'); ?>
      </div>

    <?php echo $__env->make('layout.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('layout.control-slidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="control-sidebar-bg"></div>
  </div>
  <?php echo $__env->make('layout.script', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>
</html>
