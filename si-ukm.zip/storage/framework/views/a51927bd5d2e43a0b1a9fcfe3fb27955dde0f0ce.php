<?php $__env->startSection('content'); ?>

<link rel="stylesheet" href="<?php echo e(url('/assets/dist/css/skins/_all-skins.min.css')); ?>">
  <!-- bootstrap wysihtml5 - text editor -->
<link rel="stylesheet" href="<?php echo e(url('/assets/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css')); ?>">

<section class="content-header">
<h1>
  Edit Profil UKM
  <!-- <small>Lihat Profil UKM</small> -->
</h1>
<ol class="breadcrumb">
  <li><a href="<?php echo e(route('profilUkm.index')); ?>"><i class="fa fa-user"></i>Profil UKM</a></li>
  <li class="active">Edit Profil UKM</li>
</ol>
</section>

<section class="content">
  <div class="row">

    <div class="col-md-9">
      <!-- general form elements -->
      <div class="box box-primary">
        <div class="box-header with-border">
          <h3 class="box-title">Form Edit Profil UKM</h3>
        </div>
        <!-- /.box-header -->
        <!-- form start -->
        <form role="form">
          <div class="box-body">
            <div class="form-group">
              <label for="namaUkm">Nama UKM</label>
              <input type="text" class="form-control" id="namaUkm" name="namaUkm" placeholder="Nama UKM..." style="width: 400px;">
            </div>
            <div class="form-group">
              <label for="profil">Profil</label>
              <textarea class="form-control" name="profil" id="profil" rows="3" placeholder="Sekilas profil tentang UKM ..."></textarea>
            </div>
            <div class="form-group">
              <label for="visi">Visi</label>
              <textarea class="form-control" name="visi" id="visi" rows="3" placeholder="Visi ..."></textarea>
            </div>
            <div class="form-group">
              <label for="misi">Misi</label>
                <textarea class="textarea" name="misi" id="misi" placeholder="Misi ..."
                          style="width: 100%; height: 200px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;"></textarea>
            </div>
            <div class="form-group">
              <label for="foto">Geleri Foto Kegiatan Unggulan</label>
              <div class="row">
                <div class="col-md-2">
                  <img class="img-square" src="<?php echo e(url('/foto/ukm/mpaAb.jpg')); ?>" alt="Logo UKM" style="width: 100%;">
                </div>
                <div class="col-md-2">
                  <img class="img-square" src="<?php echo e(url('/foto/ukm/mpaAb.jpg')); ?>" alt="Logo UKM" style="width: 100%;">
                </div>
                <div class="col-md-2">
                  <img class="img-square" src="<?php echo e(url('/foto/ukm/mpaAb.jpg')); ?>" alt="Logo UKM" style="width: 100%;">
                </div>
                <div class="col-md-2">
                  <img class="img-square" src="<?php echo e(url('/foto/ukm/mpaAb.jpg')); ?>" alt="Logo UKM" style="width: 100%;">
                </div>
                <div class="col-md-2">
                  <img class="img-square" src="<?php echo e(url('/foto/ukm/mpaAb.jpg')); ?>" alt="Logo UKM" style="width: 100%;">
                </div>
                <div class="col-md-2">
                  <img class="img-square" src="<?php echo e(url('/foto/ukm/mpaAb.jpg')); ?>" alt="Logo UKM" style="width: 100%;">
                </div>
              </div>
            </div>

          </div>
          <!-- /.box-body -->
          <div class="box-footer">
            <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
          </div>
      </div>
    </div>

    <div class="col-md-3">
      <div class="box box-primary">
        <div class="box-header with-border">
          <h3 class="box-title">Logo UKM</h3>
        </div>
        <div class="box-body">
          <img class="img-square" src="<?php echo e(url('/foto/ukm/mpaAb.jpg')); ?>" alt="Logo UKM" style="width: 100%;">
          <hr>
          <input type="file" name="logo_ukm" class="btn btn-primary col-md-12">
        </div>
      </div>
    </div>

    <div class="col-md-3">
      <div class="box box-primary">
        <div class="box-header with-border">
          <h3 class="box-title">Struktur Kepengurusan</h3>
        </div>
        <div class="box-body">
          <img class="img-square" src="<?php echo e(url('/foto/struktur/hf.png')); ?>" alt="Logo UKM" style="width: 100%;">
          <hr>
          <input type="file" name="struktur_kepengurusan" class="btn btn-primary col-md-12">
        </div>
      </div>
    </div>

  </form>

  </div>
</section>


<script src="<?php echo e(url('/assets/bower_components/ckeditor/ckeditor.js')); ?>"></script>
<script src="<?php echo e(url('/assets/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js')); ?>"></script>
<script>
  $(function () {
    // Replace the <textarea id="editor1"> with a CKEditor
    // instance, using default configuration.
    CKEDITOR.replace('editor1')
    //bootstrap WYSIHTML5 - text editor
    $('.textarea').wysihtml5()
  })
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminUkm.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>