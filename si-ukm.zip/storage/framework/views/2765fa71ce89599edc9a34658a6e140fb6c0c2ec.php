<?php $__env->startSection('content'); ?>

<!-- bootstrap datepicker -->

  <section class="content-header">
  <h1>
    Berita UKM
    <!-- <small>Lihat Profil UKM</small> -->
  </h1>
  <ol class="breadcrumb">
    <li><a href="#"><i class="fa fa-user"></i>Profil Ukm</a></li>
    <li class="active">Baca Berita</li>
  </ol>
  </section>

  <section class="content">
      <div class="row">
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Baca Berita</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
              <div class="box-body">

                <div class="post">
                  <div class="user-block">
                    <span class="username" style="margin-left: 0px; margin-botom:5px;">
                      <a href="#"><?php echo e($berita[0]['judul_berita']); ?></a>
                    </span>
                    <span class="description" style="margin-left: 0px; padding-top:5px;">
                      <i class="fa fa-tag"></i> &nbsp;<?php echo e($ukm[0]['nama_ukm']); ?> | &nbsp;
                      <i class="fa fa-calendar"></i> &nbsp;<?php echo e($berita[0]['tanggal_berita']); ?> | &nbsp;
                      <i class="fa fa-lock"></i> &nbsp;<?php echo e($berita[0]['sifat_berita']); ?>

                    </span>
                  </div>
                  <hr>
                  <!-- /.user-block -->
                  <p>
                    <?php echo $berita[0]['isi_berita']; ?>

                  </p>
                  <br>
                </div>

            </div>
          </div>
        </div>
  </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>