<form action="<?php echo e(route('guest.kirimEmailPassword')); ?>" method="post">
<?php echo e(csrf_field()); ?>

<input type="text" name="username" requred> 
<input type="email" name="email" required>
<input type="submit" value="Kirim">
</form>
