<?php $__env->startSection('content'); ?>
  <h1>Bla</h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>