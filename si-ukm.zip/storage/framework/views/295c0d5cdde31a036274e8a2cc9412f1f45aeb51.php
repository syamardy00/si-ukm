<?php $__env->startSection('content'); ?>

  <section class="content-header">
  <h1>
    Program Kerja
    <!-- <small>Lihat Profil UKM</small> -->
  </h1>
  <ol class="breadcrumb">
    <li><a href="<?php echo e(route('prokerUkm.index')); ?>"><i class="fa fa-user"></i>Program Kerja</a></li>
    <li class="active">Semua Proker</li>
  </ol>
  </section>

  <section class="content">
    <div class="row">



    </div>
  </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminUkm.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>