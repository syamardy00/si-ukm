<?php $__env->startSection('content'); ?>

<link href="<?php echo e(url('/assets/galeri/css/style.css')); ?>" rel="stylesheet"/>

<!-- CSS Lightbox -->
<link href="<?php echo e(url('/assets/galeri/css/lightbox.css')); ?>" rel="stylesheet"/>

  <section class="content-header">
  <h1>
    Galeri Foto
    <!-- <small>Lihat Profil UKM</small> -->
  </h1>
  <ol class="breadcrumb">
    <li><a href="<?php echo e(route('galeriFoto.index')); ?>"><i class="fa fa-user"></i>Galeri Foto</a></li>
    <li class="active">Lihat Galeri</li>
  </ol>
  </section>

  <section class="content">
    <div class="row">
      <?php if(Session::has('berhasil')): ?>
        <div class="col-md-12">
          <div class="alert alert-success alert-dismissible" style="border-left:10px solid #00733E;">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <h4><i class="icon fa fa-check"></i> Operasi Berhasil!</h4>
            <?php echo e(Session::get('berhasil')); ?>

          </div>
        </div>
      <?php endif; ?>

      <div class="col-md-12">
        <!-- general form elements -->
        <div class="box box-primary">
          <div class="box-header with-border">
            <div class="pull-left">
              <h3 class="box-title">Galeri Foto UKM</h3>
            </div>
            <div class="pull-right">
              <?php if($hitung >= 10): ?>
                <a class="btn btn-primary" data-toggle="modal" data-target="#modal-foto-maksimal"><i class="fa fa-ban"></i> Jumlah Foto Maksimal</a>
              <?php else: ?>
                <a class="btn btn-primary" data-toggle="modal" data-target="#modal-tambah-foto"><i class="fa fa-plus"></i> Tambah Foto Baru</a>
              <?php endif; ?>
            </div>
            <br><hr>
            <div class="col-md-12" style="padding:0px;">
              <div class="alert alert-info alert-dismissible" style="border-left:10px solid #0097BC;">
                <h4><i class="icon fa fa-info"></i> Info</h4>
                Galeri foto dari kegiatan-kegiatan unggulan UKM, galeri foto hanya dapat berisi maksimal 10 foto unggulan saja.
                Untuk menambahkan foto baru silahkan klik tombol "<b>Tambah Foto Baru</b>" diatas.
              </div>
            </div>
          </div>

          <div class="box-body">
          <?php if(sizeOf($foto) == 0): ?>
            <center><h4>Belum Ada Foto</h4></center>
          <?php endif; ?>
          <?php $no=0; ?>
          <?php $__currentLoopData = $foto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($no == 0 || $no == 3 || $no == 6 || $no == 9): ?>
              <div class="row">
            <?php endif; ?>
            <div class="col-md-4" style="margin-bottom:30px;">
              <div style="">
                <div class="well" style="margin:0px; height:360px; background:#3A3F4B; color:#fff;">
                    <a class="example-image-link" href="<?php echo e($f->foto); ?>" data-lightbox="example-set" data-title="<?php echo e($f->keterangan); ?>">
                      <div class="widget-user-image img-rounded" style="text-align: right; right:20px; text-align:center; height:200px; width:100%;
                      background:url(<?php echo e(url($f->foto)); ?>); background-size:cover; background-position:center;">
                      </div>
                      <!-- <img class="thumbnail img-responsive" alt="Bootstrap template" src="<?php echo e($f->foto); ?>" /> -->
                    </a>
                    <br>
                    <div style="padding:5px; padding-bottom:1px; background:#313640; height:70px; margin-top:0px;">
                      <p><?php echo e(substr($f->keterangan, 0, 120)); ?></p>
                    </div>
                    <a class="btn btn-xs btn-danger col-md-10" data-toggle="modal" data-target="#modal-hapus-foto<?php echo e($f->id); ?>" style="bottom:10px; left:30px; position:absolute;">Hapus</a>
                </div>
              </div>
            </div>
            <?php if($no == 2 || $no == 5 || $no == 8 || $no == 9): ?>
          </div>
            <?php endif; ?>
          <?php $no++; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          </div>
        </div>
      </div>
    </div>

      <div class="modal modal-info fade" id="modal-tambah-foto">
        <form action="<?php echo e(route('galeriFoto.store')); ?>" method="post"  enctype="multipart/form-data">
          <?php echo e(csrf_field()); ?>

          <?php echo e(method_field('POST')); ?>

        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span></button>
              <h4 class="modal-title">Tambahkan Foto Baru</h4>
            </div>
            <div class="modal-body" style="min-height:330px;">
              <div class="col-md-5">
                <img class="img-square" id="foto" src="<?php echo e(url('/foto/default-image.png')); ?>" alt="Logo UKM" style="width: 100%;">
                <hr>
                <input type="file" name="foto" value="<?php echo e(old('foto')); ?>" id="previewFoto" class="btn btn-primary col-md-12" required>
              </div>
              <div class="col-md-7">
                <label class="control-label">Keterangan Foto :</label>
                <textarea class="form-control" name="keterangan" style="width:100%; height: 120px;" placeholder="Keterangan Foto..." required></textarea>
                <p class="text-white">Masukan keterangan singkat mengenai foto. Maksimal 250 Karakter.</p>
              </div>
            </div>
            <div class="modal-footer">
              <!-- <button type="button" class="btn btn-outline pull-left" data-dismiss="modal">Close</button> -->
              <button type="submit" class="btn btn-outline">Upload</button>
              <button type="button" data-dismiss="modal" class="btn btn-outline">Batal</button>
              </form>
            </div>
          </div>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>

      <?php $__currentLoopData = $foto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="modal modal-danger fade" id="modal-hapus-foto<?php echo e($f->id); ?>">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span></button>
              <h4 class="modal-title">Konfirmasi</h4>
            </div>
            <div class="modal-body">
              <p>Anda yakin akan menghapus foto?</p>
            </div>
            <div class="modal-footer">
              <!-- <button type="button" class="btn btn-outline pull-left" data-dismiss="modal">Close</button> -->
              <form action="<?php echo e(route('galeriFoto.destroy', $f->id)); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('DELETE')); ?>

                        <button type="submit" class="btn btn-outline">Ya</button>
                        <button type="button" data-dismiss="modal" class="btn btn-outline">Batal</button>
              </form>

            </div>
          </div>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      <div class="modal modal-warning fade" id="modal-foto-maksimal">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span></button>
              <h4 class="modal-title">Jumlah Foto Maksimal</h4>
            </div>
            <div class="modal-body">
              <p>Tidak bisa menambahkan foto baru, jumlah foto dalam galeri sudah
              mencapai batas maksimal, yaitu 10 foto. Hapus foto terlebih dahulu untuk
            manambahkan foto baru.</p>
            </div>
            <div class="modal-footer">
              <button type="button" data-dismiss="modal" class="btn btn-outline">Tutup</button>
            </div>
          </div>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>

  </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<!-- jQuery Lightbox -->
<script src="<?php echo e(url('/assets/galeri/js/lightbox-plus-jquery.min.js')); ?>"></script>
<script>
  function bacaFoto(input){
    if(input.files && input.files[0]){
      var reader = new FileReader();

      reader.onload = function(e){
        $('#foto').attr('src', e.target.result);
      }

      reader.readAsDataURL(input.files[0]);

    }
  }

  $('#previewFoto').change(function(){
    bacaFoto(this);
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminUkm.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>