<?php if(Auth::guard('adminUkm')->check()): ?>
  <?php echo $__env->make('adminUkm.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php elseif(Auth::guard('admin')->check()): ?>
  <?php echo $__env->make('admin.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php elseif(Auth::guard('anggotaUkm')->check()): ?>
  <?php echo $__env->make('anggotaUkm.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php elseif(Auth::guard('bem')->check()): ?>
  <?php echo $__env->make('pengawas.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php elseif(Auth::guard('wd1')->check()): ?>
  <?php echo $__env->make('pengawas.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php else: ?>

<?php endif; ?>
