<?php $__env->startSection('content'); ?>

  <section class="content-header">
  <h1>
    Semua Berita
    <!-- <small>Lihat Profil UKM</small> -->
  </h1>
  <ol class="breadcrumb">
    <li><a href="<?php echo e(route('beritaUkm.index')); ?>"><i class="fa fa-user"></i>Berita Ukm</a></li>
    <li class="active">Semua Berita</li>
  </ol>
  </section>

  <section class="content">
    <div class="row">



    </div>
  </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminUkm.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>