<!DOCTYPE html>
<html>
<head>
<?php echo $__env->make('adminlte.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">
<?php echo $__env->make('adminlte.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <!-- Left side column. contains the logo and sidebar -->
<?php echo $__env->make('adminlte.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  <!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <?php echo $__env->yieldContent('content'); ?>
</div>
  <!-- /.content-wrapper -->
<?php echo $__env->make('adminlte.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  <!-- Control Sidebar -->
<?php echo $__env->make('adminlte.control-slidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->
<?php echo $__env->make('adminlte.script', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</body>
</html>
