<?php $__env->startSection('content'); ?>

  <section class="content-header">
  <h1>
    Semua Berita
    <!-- <small>Lihat Profil UKM</small> -->
  </h1>
  <ol class="breadcrumb">
    <?php if(Auth::guard('anggotaUkm')->check()): ?>
      <li><a href="<?php echo e(route('anggotaUkm.ukm.dashboardProfilUkm')); ?>"><i class="fa fa-dashboard"></i>Dashboard</a></li>
    <?php elseif(Auth::guard('monitoring')->check()): ?>
      <li><a href="#"><i class="fa fa-tv"></i>Monitoring</a></li>
    <?php else: ?>
      <li><a href="<?php echo e(route('home')); ?>"><i class="fa fa-home"></i>Home</a></li>
    <?php endif; ?>
    <li class="active">Berita</li>
  </ol>
  </section>

  <section class="content">
    <div class="row">
      <!-- berita -->
        <div class="col-md-12">
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
            <li class="active"><a href="#semua" data-toggle="tab">Berita</a></li>
            </ul>
            <div class="tab-content">

            <div class="active tab-pane" id="umum">
              <?php if(sizeOf($beritaU) == 0): ?>
                <center><h4>Belum Ada Berita</h4></center>
              <?php endif; ?>
              <?php $__currentLoopData = $beritaU; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <!-- Post -->
              <div class="post">
                <div class="user-block">
                  <span class="username" style="margin-left: 0px;">
                  <?php if(Auth::guard('monitoring')->check()): ?>
                    <a href="<?php echo e(url('/monitoring/berita-ukm/baca/'.$b->id)); ?>"><?php echo e($b->judul_berita); ?></a>
                  <?php elseif(Auth::guard('anggotaUkm')->check()): ?>
                    <a href="<?php echo e(url('/ukm/profil-ukm/berita/baca/'.$b->id)); ?>"><?php echo e($b->judul_berita); ?></a>
                  <?php else: ?>
                    <a href="<?php echo e(url('/home/berita-ukm/baca/'.$b->id)); ?>"><?php echo e($b->judul_berita); ?></a>
                  <?php endif; ?>
                  </span>
                  <span class="description" style="margin-left: 0px;">
                    <i class="fa fa-calendar"></i> &nbsp;<?php echo e($b->tanggal_berita); ?> | &nbsp;
                    <i class="fa fa-lock"></i> &nbsp;<?php echo e($b->sifat_berita); ?>

                  </span>
                </div>
                <!-- /.user-block -->
                <p>
                  <?php echo e(strip_tags(str_replace("&nbsp;", '', substr($b->isi_berita, 0, 300)))); ?>

                </p>
                <ul class="list-inline">
                <li class="pull-right">
                <?php if(Auth::guard('monitoring')->check()): ?>
                  <a href="<?php echo e(url('/monitoring/berita-ukm/baca/'.$b->id)); ?>" class="link-black text-sm"><i class="fa fa-eye margin-r-5"></i> Baca Berita
                  </a></li>
                <?php elseif(Auth::guard('anggotaUkm')->check()): ?>
                  <a href="<?php echo e(url('/ukm/profil-ukm/berita/baca/'.$b->id)); ?>" class="link-black text-sm"><i class="fa fa-eye margin-r-5"></i> Baca Berita
                  </a></li>
                <?php else: ?>
                  <a href="<?php echo e(url('/home/berita-ukm/baca/'.$b->id)); ?>" class="link-black text-sm"><i class="fa fa-eye margin-r-5"></i> Baca Berita
                  </a></li>
                <?php endif; ?>
                </ul>
                <br>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php echo e($beritaU->links()); ?>

            </div>
            </div>
            <!-- /.tab-content -->
            </div>
        </div>

    </div>
  </section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>
