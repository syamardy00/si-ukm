<?php $__env->startSection('content'); ?>

<section class="content-header">
<h1>
  Profil UKM
  <!-- <small>Lihat Profil UKM</small> -->
</h1>
<ol class="breadcrumb">
  <li><a href="#"><i class="fa fa-user"></i> Profil UKM</a></li>
  <li class="active">Lihat Profil UKM</li>
</ol>
</section>

<section class="content">

  <div class="row">
    <div class="col-md-12">
      <!-- Widget: user widget style 1 -->
      <div class="box box-widget widget-user">
        <!-- Add the bg color to the header using any of the bg-* classes -->
        <div class="widget-user-header" style="background: #2C3B41; color:white;">
          <h3 class="widget-user-username" style="font-size: 30pt;"><?php echo e($ukm[0]['nama_ukm']); ?></h3>
          <h5 class="widget-user-desc">Politeknik TEDC Bandung</h5>
        </div>
        <div class="widget-user-image" style="margin-top: -45px; text-align: right; right:20px;">
          <img class="img-square" src="<?php echo e($ukm[0]['logo_ukm']); ?>" alt="User Avatar" style="width: 180px; height: 180px;">
        </div>
        <div class="box-footer">
          <div class="row">
            <div class="col-sm-10">
              <div class="description-block" style="text-align: left;">
                <h5 class="description-header" style="margin-top: -25px;">Profil</h5>
                <span>
                  <?php echo e($ukm[0]['profil']); ?>

                </span>
              </div>
            </div>
            <!-- /.col -->
          </div>
          <!-- /.row -->
        </div>
      </div>
      <!-- /.widget-user -->
    </div>
  </div>

  <div class="row">
    <div class="col-md-6">
      <div class="box box-primary">
        <div class="box-header with-border">
          <h3 class="box-title">Visi</h3>
          <div class="box-tools pull-right">
            <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
            </button>
          </div>
          <!-- /.box-tools -->
        </div>
        <!-- /.box-header -->
        <div class="box-body">
          <?php echo e($ukm[0]['visi']); ?>

        </div>
        <!-- /.box-body -->
      </div>
      <!-- /.box -->
    </div>

    <div class="col-md-6">
      <div class="box box-primary">
        <div class="box-header with-border">
          <h3 class="box-title">Misi</h3>
          <div class="box-tools pull-right">
            <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
            </button>
          </div>
          <!-- /.box-tools -->
        </div>
        <!-- /.box-header -->
        <div class="box-body">
          <?php echo e($ukm[0]['misi']); ?>

        </div>
        <!-- /.box-body -->
      </div>
      <!-- /.box -->
    </div>
  </div>

  <div class="row">
    <div class="col-md-8">
      <div class="box box-primary">
        <div class="box-header with-border">
          <h3 class="box-title">Struktur Kepengurusan</h3>
          <!-- /.box-tools -->
        </div>
        <!-- /.box-header -->
        <div class="box-body">
          <div class="widget-user-image">
            <img class="img-square" src="<?php echo e(url('/foto/struktur/hf.png')); ?>" alt="User Avatar" style="width: 100%; height: 500px;">
          </div>
        </div>
        <!-- /.box-body -->
      </div>
      <!-- /.box -->
    </div>

    <div class="col-md-4">
      <div class="box box-primary">
        <div class="box-header with-border">
          <h3 class="box-title">Galeri Kegiatan</h3>
          <!-- /.box-tools -->
        </div>
        <!-- /.box-header -->
        <!-- /.box-body -->
      </div>
      <!-- /.box -->
    </div>

    <div class="col-md-2">
      <div class="box box-primary">
        <div class="box-body">
          <img class="img-square" src="<?php echo e(url('/foto/galeri/contoh.jpg')); ?>" alt="User Avatar" style="width: 100%; height: 130px;">
        </div>
      </div>
    </div>

    <div class="col-md-2">
      <div class="box box-primary">
        <div class="box-body">
          <img class="img-square" src="<?php echo e(url('/foto/galeri/contoh2.jpg')); ?>" alt="User Avatar" style="width: 100%; height: 130px;">
        </div>
      </div>
    </div>

    <div class="col-md-2">
      <div class="box box-primary">
        <div class="box-body">
          <img class="img-square" src="<?php echo e(url('/foto/galeri/contoh3.jpg')); ?>" alt="User Avatar" style="width: 100%; height: 130px;">
        </div>
      </div>
    </div>

    <div class="col-md-2">
      <div class="box box-primary">
        <div class="box-body">
          <img class="img-square" src="<?php echo e(url('/foto/galeri/d.jpg')); ?>" alt="User Avatar" style="width: 100%; height: 130px;">
        </div>
      </div>
    </div>

    <div class="col-md-2">
      <div class="box box-primary">
        <div class="box-body">
          <img class="img-square" src="<?php echo e(url('/foto/galeri/5.jpg')); ?>" alt="User Avatar" style="width: 100%; height: 130px;">
        </div>
      </div>
    </div>

    <div class="col-md-2">
      <div class="box box-primary">
        <div class="box-body">
          <img class="img-square" src="<?php echo e(url('/foto/galeri/6.jpg')); ?>" alt="User Avatar" style="width: 100%; height: 130px;">
        </div>
      </div>
    </div>
  </div>
<!-- berita -->
  <div class="row">
    <div class="col-md-12">
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
              <li class="active"><a href="#semuaBerita" data-toggle="tab">Semua Berita</a></li>
              <li><a href="#beritaInternal" data-toggle="tab">Berita Internal</a></li>
              <li><a href="#beritaUmum" data-toggle="tab">Berita Umum</a></li>
            </ul>
            <div class="tab-content">
              <!-- /.tab-pane -->

              <!-- start item tab -->
              <div class="tab-pane active" id="semuaBerita">
                <ul class="timeline timeline-inverse">
                  <li class="time-label">
                        <span class="bg-red">
                          Semua Berita
                        </span>
                  </li>

                  <!-- item berita -->
                  <li>
                    <i class="fa fa-feed bg-blue"></i>

                    <div class="timeline-item">
                      <span class="time"><i class="fa fa-clock-o"></i> 12:05</span>

                      <h3 class="timeline-header"><a href="#">Support Team</a> sent you an email</h3>

                      <div class="timeline-body">
                        Etsy doostang zoodles disqus groupon greplin oooj voxy zoodles,
                        weebly ning heekya handango imeem plugg dopplr jibjab, movity
                        jajah plickers sifteo edmodo ifttt zimbra. Babblely odeo kaboodle
                        quora plaxo ideeli hulu weebly balihoo...
                      </div>
                      <!-- <div class="timeline-footer">
                        <a class="btn btn-primary btn-xs">Read more</a>
                        <a class="btn btn-danger btn-xs">Delete</a>
                      </div> -->
                    </div>
                  </li>
                  <!-- end item berita -->

                  <!-- item berita -->
                  <li>
                    <i class="fa fa-feed bg-blue"></i>

                    <div class="timeline-item">
                      <span class="time"><i class="fa fa-clock-o"></i> 12:05</span>

                      <h3 class="timeline-header"><a href="#">Support Team</a> sent you an email</h3>

                      <div class="timeline-body">
                        Etsy doostang zoodles disqus groupon greplin oooj voxy zoodles,
                        weebly ning heekya handango imeem plugg dopplr jibjab, movity
                        jajah plickers sifteo edmodo ifttt zimbra. Babblely odeo kaboodle
                        quora plaxo ideeli hulu weebly balihoo...
                      </div>
                      <!-- <div class="timeline-footer">
                        <a class="btn btn-primary btn-xs">Read more</a>
                        <a class="btn btn-danger btn-xs">Delete</a>
                      </div> -->
                    </div>
                  </li>
                  <!-- end item berita -->

                </ul>
              </div>
              <!-- end item tab -->

              <!-- start item tab -->
              <div class="tab-pane" id="beritaUmum">
                <ul class="timeline timeline-inverse">
                  <li class="time-label">
                        <span class="bg-red">
                          Berita Umum
                        </span>
                  </li>

                  <!-- item berita -->
                  <li>
                    <i class="fa fa-feed bg-blue"></i>

                    <div class="timeline-item">
                      <span class="time"><i class="fa fa-clock-o"></i> 12:05</span>

                      <h3 class="timeline-header"><a href="#">Support Team</a> sent you an email</h3>

                      <div class="timeline-body">
                        Etsy doostang zoodles disqus groupon greplin oooj voxy zoodles,
                        weebly ning heekya handango imeem plugg dopplr jibjab, movity
                        jajah plickers sifteo edmodo ifttt zimbra. Babblely odeo kaboodle
                        quora plaxo ideeli hulu weebly balihoo...
                      </div>
                      <!-- <div class="timeline-footer">
                        <a class="btn btn-primary btn-xs">Read more</a>
                        <a class="btn btn-danger btn-xs">Delete</a>
                      </div> -->
                    </div>
                  </li>
                  <!-- end item berita -->

                  <!-- item berita -->
                  <li>
                    <i class="fa fa-feed bg-blue"></i>

                    <div class="timeline-item">
                      <span class="time"><i class="fa fa-clock-o"></i> 12:05</span>

                      <h3 class="timeline-header"><a href="#">Support Team</a> sent you an email</h3>

                      <div class="timeline-body">
                        Etsy doostang zoodles disqus groupon greplin oooj voxy zoodles,
                        weebly ning heekya handango imeem plugg dopplr jibjab, movity
                        jajah plickers sifteo edmodo ifttt zimbra. Babblely odeo kaboodle
                        quora plaxo ideeli hulu weebly balihoo...
                      </div>
                      <!-- <div class="timeline-footer">
                        <a class="btn btn-primary btn-xs">Read more</a>
                        <a class="btn btn-danger btn-xs">Delete</a>
                      </div> -->
                    </div>
                  </li>
                  <!-- end item berita -->

                </ul>
              </div>
              <!-- end item tab -->

              <!-- start item tab -->
              <div class="tab-pane" id="beritaInternal">
                <ul class="timeline timeline-inverse">
                  <li class="time-label">
                        <span class="bg-red">
                          Berita Internal
                        </span>
                  </li>

                  <!-- item berita -->
                  <li>
                    <i class="fa fa-feed bg-blue"></i>

                    <div class="timeline-item">
                      <span class="time"><i class="fa fa-clock-o"></i> 12:05</span>

                      <h3 class="timeline-header"><a href="#">Support Team</a> sent you an email</h3>

                      <div class="timeline-body">
                        Etsy doostang zoodles disqus groupon greplin oooj voxy zoodles,
                        weebly ning heekya handango imeem plugg dopplr jibjab, movity
                        jajah plickers sifteo edmodo ifttt zimbra. Babblely odeo kaboodle
                        quora plaxo ideeli hulu weebly balihoo...
                      </div>
                      <!-- <div class="timeline-footer">
                        <a class="btn btn-primary btn-xs">Read more</a>
                        <a class="btn btn-danger btn-xs">Delete</a>
                      </div> -->
                    </div>
                  </li>
                  <!-- end item berita -->

                  <!-- item berita -->
                  <li>
                    <i class="fa fa-feed bg-blue"></i>

                    <div class="timeline-item">
                      <span class="time"><i class="fa fa-clock-o"></i> 12:05</span>

                      <h3 class="timeline-header"><a href="#">Support Team</a> sent you an email</h3>

                      <div class="timeline-body">
                        Etsy doostang zoodles disqus groupon greplin oooj voxy zoodles,
                        weebly ning heekya handango imeem plugg dopplr jibjab, movity
                        jajah plickers sifteo edmodo ifttt zimbra. Babblely odeo kaboodle
                        quora plaxo ideeli hulu weebly balihoo...
                      </div>
                      <!-- <div class="timeline-footer">
                        <a class="btn btn-primary btn-xs">Read more</a>
                        <a class="btn btn-danger btn-xs">Delete</a>
                      </div> -->
                    </div>
                  </li>
                  <!-- end item berita -->

                </ul>
              </div>
              <!-- end item tab -->

            </div>
          </div>
        </div>
  </div>

</secsection>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminUkm.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>