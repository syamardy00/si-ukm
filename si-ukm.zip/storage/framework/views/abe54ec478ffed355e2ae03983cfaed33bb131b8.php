<?php $__env->startSection('content'); ?>

<section class="content-header">
<h1>
  Profil UKM
  <!-- <small>Lihat Profil UKM</small> -->
</h1>
<ol class="breadcrumb">
  <li><a href="#"><i class="fa fa-user"></i> Profil UKM</a></li>
  <li class="active">Lihat Profil UKM</li>
</ol>
</section>

<section class="content">

  <div class="row">

    <?php if(Session::has('berhasil')): ?>
      <div class="col-md-12">
        <div class="alert alert-success alert-dismissible" style="border-left:10px solid #00733E;">
          <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
          <h4><i class="icon fa fa-check"></i> Operasi Berhasil!</h4>
          <?php echo e(Session::get('berhasil')); ?>

        </div>
      </div>
    <?php endif; ?>

    <div class="col-md-12">
      <!-- Widget: user widget style 1 -->
      <div class="box box-widget widget-user">
        <!-- Add the bg color to the header using any of the bg-* classes -->
        <div class="widget-user-header" style="background: #2C3B41; color:white;">
          <p class="nama-ukm"><?php echo e($ukm[0]['nama_ukm']); ?></p>
          <p class="nama-poltek">Politeknik TEDC Bandung</p>
          <a href="#" data-toggle="modal" data-target="#modal-logo">
            <div class="col-md-2 pull-right logo-ukm" style="padding:0px;">
            <?php if($ukm[0]['logo_ukm']): ?>
              <img class="img-square logo_ukm" src="<?php echo e($ukm[0]['logo_ukm']); ?>">
            <?php else: ?>
              <img class="img-square logo_ukm" src="<?php echo e(url('/foto/default-image.png')); ?>">
            <?php endif; ?>
            </div>
          </a>
        </div>
        <div class="box-footer">
          <div class="row">
            <div class="col-sm-10">
              <div class="description-block" style="text-align: left; min-height: 70px;">
                <h5 class="description-header" style="margin-top: -25px;">Profil</h5>
                <span>
                  <?php if($ukm[0]['profil']): ?>
                    <?php echo e($ukm[0]['profil']); ?>

                  <?php else: ?>
                    <h4><center>Data Belum Ada</center></h4>
                  <?php endif; ?>
                </span>
              </div>
            </div>
            <!-- /.col -->
          </div>
          <div class="row">
            <div class="col-sm-3 border-right">
              <div class="description-block">
                <!-- <h5 class="description-header">3,200</h5> -->
                <span class="">
                  <i class="fa fa-phone"></i>&nbsp;
                  <?php if($ukm[0]['no_telepon']): ?>
                    <?php echo e($ukm[0]['no_telepon']); ?>

                  <?php else: ?>
                    &nbsp; -
                  <?php endif; ?>
                </span>
              </div>
              <!-- /.description-block -->
            </div>

            <div class="col-sm-3 border-right">
              <div class="description-block">
                <!-- <h5 class="description-header">3,200</h5> -->
                <span class="">
                  <i class="fa fa-envelope"></i>&nbsp;
                  <?php if($ukm[0]['email']): ?>
                    <?php echo e($ukm[0]['email']); ?>

                  <?php else: ?>
                    &nbsp; -
                  <?php endif; ?>
                </span>
              </div>
              <!-- /.description-block -->
            </div>
            <!-- /.col -->
            <div class="col-sm-3 border-right">
              <div class="description-block">
                <!-- <h5 class="description-header">13,000</h5> -->
                <span class="">
                  <i class="fa fa-instagram"></i>&nbsp;
                  <?php if($ukm[0]['instagram']): ?>
                    <a href="https://www.instagram.com/<?php echo e($ukm[0]['instagram']); ?>" target="_blank"><?php echo e($ukm[0]['instagram']); ?></a>
                  <?php else: ?>
                    &nbsp; -
                  <?php endif; ?>
                </span>
              </div>
              <!-- /.description-block -->
            </div>
            <!-- /.col -->
            <div class="col-sm-3">
              <div class="description-block">
                <!-- <h5 class="description-header">35</h5> -->
                <span class="">
                  <i class="fa fa-globe"></i>&nbsp;
                  <?php if($ukm[0]['website']): ?>
                    <a href="https://<?php echo e($ukm[0]['website']); ?>" target="_blank"><?php echo e($ukm[0]['website']); ?></a>
                  <?php else: ?>
                    &nbsp; -
                  <?php endif; ?>
                </span>
              </div>
              <!-- /.description-block -->
            </div>
            <!-- /.col -->
          </div>
          <!-- /.row -->
        </div>
      </div>
      <!-- /.widget-user -->
    </div>
  </div>

  <div class="row">

    <!-- kolom kiri -->
    <div class="col-md-6" style="padding:0px;">
      <div class="col-md-12">
        <div class="box box-primary" style="min-height: 125px;">
          <div class="box-header with-border">
            <h3 class="box-title">Visi</h3>
            <!-- /.box-tools -->
          </div>
          <!-- /.box-header -->
          <div class="box-body">
            <?php if($ukm[0]['visi']): ?>
              <?php echo e($ukm[0]['visi']); ?>

            <?php else: ?>
              <h4><center>Data Belum Ada</center></h4>
            <?php endif; ?>
          </div>
          <!-- /.box-body -->
        </div>
        <!-- /.box -->
      </div>

      <div class="col-md-12">
        <div class="box box-primary" style="min-height: 203px;">
          <div class="box-header with-border">
            <h3 class="box-title">Misi</h3>
            <!-- /.box-tools -->
          </div>
          <!-- /.box-header -->
          <div class="box-body">
            <?php if($ukm[0]['misi']): ?>
              <?php echo $ukm[0]['misi']; ?>

            <?php else: ?>
              <h4><center>Data Belum Ada</center></h4>
            <?php endif; ?>
          </div>
          <!-- /.box-body -->
        </div>
        <!-- /.box -->
      </div>

      <div class="col-md-12">
        <div class="box box-primary">
          <div class="box-header with-border">
            <h3 class="box-title">Galeri Kegiatan</h3>
          </div>
          <!-- /.box-header -->
          <div class="box-body">
            <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
              <div class="carousel-inner">
                <?php $no = 1 ?>
                <?php if(sizeOf($foto) == 0): ?>
                  <div class="item active">
                    <img src="<?php echo e(url('/foto/default-image.png')); ?>" alt="First slide">
                    <div class="carousel-caption" style="background:rgba(0.16, 0.17, 0.20, 0.5); margin:0px; left:0; bottom:0; width:100%;">
                      Belum Ada Foto
                    </div>
                  </div>
                <?php endif; ?>
                <?php $__currentLoopData = $foto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($no == 1): ?>
                    <div class="item active">
                  <?php else: ?>
                    <div class="item">
                  <?php endif; ?>
                      <img src="<?php echo e($f->foto); ?>" alt="First slide">
                    <div class="carousel-caption" style="background:rgba(0.16, 0.17, 0.20, 0.5); margin:0px; left:0; bottom:0; width:100%;">
                      <?php echo e(substr($f->keterangan, 0, 100)); ?>

                    </div>
                  </div>
                  <?php $no++ ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              </div>
              <a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
                <span class="fa fa-angle-left"></span>
              </a>
              <a class="right carousel-control" href="#carousel-example-generic" data-slide="next">
                <span class="fa fa-angle-right"></span>
              </a>
            </div>
          </div>
          <!-- /.box-body -->
        </div>
      </div>

    </div>
    <!-- end kolom kiri -->

    <div class="col-md-6" style="padding:0px;">
      <div class="col-md-12">
        <div class="box box-primary">
          <div class="box-header with-border">
            <h3 class="box-title">Struktur Kepengurusan</h3>
            <!-- /.box-tools -->
          </div>
          <!-- /.box-header -->
          <div class="box-body">
            <a href="#" data-toggle="modal" data-target="#modal-struktur">
              <div class="widget-user-image">
              <?php if($ukm[0]['struktur']): ?>
                <img class="img-square" src="<?php echo e($ukm[0]['struktur']); ?>" alt="User Avatar" style="width: 100%;">
              <?php else: ?>
                <img class="img-square" src="<?php echo e(url('/foto/default-image.png')); ?>" alt="User Avatar" style="width: 100%;">
              <?php endif; ?>
              </div>
            </a>
          </div>
          <!-- /.box-body -->
        </div>
        <!-- /.box -->
      </div>

    <!-- berita -->
      <div class="col-md-12">
        <div class="nav-tabs-custom">
          <ul class="nav nav-tabs">
          <li class="active"><a href="#semua" data-toggle="tab">Berita</a></li>
          </ul>
          <div class="tab-content" id="berita" style="min-height:80px; max-height:580px; overflow: scroll; overflow-x: hidden;">

          <div class="active tab-pane" id="umum">
            <?php if(sizeOf($beritaU) == 0): ?>
              <center><h4>Belum Ada Berita</h4></center>
            <?php endif; ?>
            <?php $__currentLoopData = $beritaU; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <!-- Post -->
            <div class="post">
              <div class="user-block">
                <span class="username" style="margin-left: 0px;">
                  <a href="<?php echo e(route('adminBeritaUkm.show', $b->id)); ?>"><?php echo e($b->judul_berita); ?></a>
                </span>
                <span class="description" style="margin-left: 0px;">
                  <i class="fa fa-calendar"></i> &nbsp;<?php echo e($b->tanggal_berita); ?> | &nbsp;
                  <i class="fa fa-lock"></i> &nbsp;<?php echo e($b->sifat_berita); ?>

                </span>
              </div>
              <!-- /.user-block -->
              <p>
                <?php echo e(strip_tags(str_replace("&nbsp;", '', substr($b->isi_berita, 0, 300)))); ?>

              </p>
              <ul class="list-inline">
              <li class="pull-right">
                <a href="<?php echo e(route('adminBeritaUkm.show', $b->id)); ?>" class="link-black text-sm"><i class="fa fa-eye margin-r-5"></i> Baca Berita
                  </a></li>
              </ul>
              <br>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          </div>
          </div>
          <!-- /.tab-content -->
          </div>
      </div>

    </div>
  </div>


  <!-- modal  -->
  <div class="modal modal-info fade" id="modal-struktur">
    <?php if($ukm[0]['struktur']): ?>
      <img class="" src="<?php echo e($ukm[0]['struktur']); ?>" style="margin:auto; top:0; right:0; left:0; bottom:0; position:absolute; width:800px;">
    <?php else: ?>
      <img class="" src="<?php echo e(url('/foto/default-image.png')); ?>" style="margin:auto; top:0; right:0; left:0; bottom:0; position:absolute; width:800px;">
    <?php endif; ?>
  </div>

  <div class="modal modal-info fade" id="modal-logo">
    <?php if($ukm[0]['logo_ukm']): ?>
      <img class="" src="<?php echo e($ukm[0]['logo_ukm']); ?>" style="margin:auto; top:0; right:0; left:0; bottom:0; position:absolute; width:500px;">
    <?php else: ?>
      <img class="" src="<?php echo e(url('/foto/default-image.png')); ?>" style="margin:auto; top:0; right:0; left:0; bottom:0; position:absolute; width:500px;">
    <?php endif; ?>
  </div>

</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>