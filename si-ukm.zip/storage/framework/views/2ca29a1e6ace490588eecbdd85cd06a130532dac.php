<?php $__env->startSection('content'); ?>

  <section class="content-header">
  <h1>
    Data Calon Anggota
    <!-- <small>Lihat Profil UKM</small> -->
  </h1>
  <ol class="breadcrumb">
    <li><a href="<?php echo e(route('calonAnggota.index')); ?>"><i class="fa fa-user"></i>Calon Anggota</a></li>
    <li class="active">Data Calon Anggota</li>
  </ol>
  </section>

  <section class="content">
    <div class="row">



    </div>
  </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminUkm.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>