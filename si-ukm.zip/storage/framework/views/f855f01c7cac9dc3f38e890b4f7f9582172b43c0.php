<?php $__env->startSection('content'); ?>

  <section class="content-header">
  <h1>
    Semua Berita
    <!-- <small>Lihat Profil UKM</small> -->
  </h1>
  <ol class="breadcrumb">
    <li><a href="<?php echo e(route('beritaUkm.semuaBerita')); ?>"><i class="fa fa-user"></i>Berita Ukm</a></li>
    <li class="active">Semua Berita</li>
  </ol>
  </section>

  <section class="content">
    <div class="row">
      <!-- berita -->
        <div class="col-md-12">
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
            <li class="active"><a href="#semua" data-toggle="tab">Semua Berita</a></li>
            <li><a href="#internal" data-toggle="tab">Berita Internal</a></li>
            <li><a href="#umum" data-toggle="tab">Berita Umum</a></li>
            </ul>
            <div class="tab-content">

            <div class="active tab-pane" id="semua">
              <?php if(sizeOf($berita) == 0): ?>
                <center><h4>Belum Ada Berita</h4></center>
              <?php endif; ?>
              <?php $__currentLoopData = $berita; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <!-- Post -->
              <div class="post">
                <div class="user-block">
                  <span class="username" style="margin-left: 0px;">
                    <a href="<?php echo e(route('beritaUkm.show', $b->id)); ?>"><?php echo e($b->judul_berita); ?></a>
                  </span>
                  <span class="description" style="margin-left: 0px;">
                    <i class="fa fa-calendar"></i> &nbsp;<?php echo e($b->tanggal_berita); ?> | &nbsp;
                    <i class="fa fa-lock"></i> &nbsp;<?php echo e($b->sifat_berita); ?>

                  </span>
                </div>
                <!-- /.user-block -->
                <p>
                  <?php echo e(strip_tags(str_replace("&nbsp;", '', substr($b->isi_berita, 0, 300)))); ?>

                </p>
                <ul class="list-inline">
                <li class="pull-right">
                  <a href="<?php echo e(route('beritaUkm.show', $b->id)); ?>" class="link-black text-sm"><i class="fa fa-eye margin-r-5"></i> Baca Berita
                    </a></li>
                </ul>
                <br>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php echo e($berita->links()); ?>

            </div>
            <!-- /.tab-pane -->

            <div class="tab-pane" id="internal">
              <?php if(sizeOf($berita) == 0): ?>
                <center><h4>Belum Ada Berita</h4></center>
              <?php endif; ?>
              <?php $__currentLoopData = $beritaI; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <!-- Post -->
              <div class="post">
                <div class="user-block">
                  <span class="username" style="margin-left: 0px;">
                    <a href="<?php echo e(route('beritaUkm.show', $b->id)); ?>"><?php echo e($b->judul_berita); ?></a>
                  </span>
                  <span class="description" style="margin-left: 0px;">
                    <i class="fa fa-calendar"></i> &nbsp;<?php echo e($b->tanggal_berita); ?> | &nbsp;
                    <i class="fa fa-lock"></i> &nbsp;<?php echo e($b->sifat_berita); ?>

                  </span>
                </div>
                <!-- /.user-block -->
                <p>
                  <?php echo e(strip_tags(str_replace("&nbsp;", '', substr($b->isi_berita, 0, 300)))); ?>

                </p>
                <ul class="list-inline">
                <li class="pull-right">
                  <a href="<?php echo e(route('beritaUkm.show', $b->id)); ?>" class="link-black text-sm"><i class="fa fa-eye margin-r-5"></i> Baca Berita
                    </a></li>
                </ul>
                <br>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php echo e($beritaI->links()); ?>

            </div>

            <div class="tab-pane" id="umum">
              <?php if(sizeOf($berita) == 0): ?>
                <center><h4>Belum Ada Berita</h4></center>
              <?php endif; ?>
              <?php $__currentLoopData = $beritaU; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <!-- Post -->
              <div class="post">
                <div class="user-block">
                  <span class="username" style="margin-left: 0px;">
                    <a href="<?php echo e(route('beritaUkm.show', $b->id)); ?>"><?php echo e($b->judul_berita); ?></a>
                  </span>
                  <span class="description" style="margin-left: 0px;">
                    <i class="fa fa-calendar"></i> &nbsp;<?php echo e($b->tanggal_berita); ?> | &nbsp;
                    <i class="fa fa-lock"></i> &nbsp;<?php echo e($b->sifat_berita); ?>

                  </span>
                </div>
                <!-- /.user-block -->
                <p>
                  <?php echo e(strip_tags(str_replace("&nbsp;", '', substr($b->isi_berita, 0, 300)))); ?>

                </p>
                <ul class="list-inline">
                <li class="pull-right">
                  <a href="<?php echo e(route('beritaUkm.show', $b->id)); ?>" class="link-black text-sm"><i class="fa fa-eye margin-r-5"></i> Baca Berita
                    </a></li>
                </ul>
                <br>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php echo e($beritaU->links()); ?>

            </div>
            </div>
            <!-- /.tab-content -->
            </div>
        </div>

    </div>
  </section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminUkm.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>