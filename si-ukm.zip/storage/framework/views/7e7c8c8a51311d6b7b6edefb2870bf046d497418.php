<h2>Reset Password</h2>
Username : <?php echo e($username); ?>

Password Baru : <?php echo e($password_baru); ?>

<h2>Sistem Informasi UKM</h2>
