<?php $__env->startSection('content'); ?>

<style>
  .example-modal .modal {
    position: relative;
    top: auto;
    bottom: auto;
    right: auto;
    left: auto;
    display: block;
    z-index: 1;
  }

  .example-modal .modal {
    background: transparent !important;
  }
</style>

  <section class="content-header">
    <h1>
      Daftar UKM Di Politeknik TEDC Bandung
      <!-- <small>Lihat Profil UKM</small> -->
    </h1>
    <ol class="breadcrumb">
      <li><a href="<?php echo e(route('admin')); ?>"><i class="fa fa-user"></i>Admin</a></li>
      <li class="active">Kelola UKM</li>
    </ol>
  </section>

  <section class="content">
    <div class="row">

      <?php $__currentLoopData = $ukm; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-md-4">
        <div class="box box-widget widget-user">
          <!-- Add the bg color to the header using any of the bg-* classes -->
          <div class="widget-user-header" style="background: #009ABF; color:white;">
            <h3 class="widget-user-username" style="font-size: 12pt;"><b><?php echo e($u->nama_ukm); ?><b></h3>
            <h6 class=col-md-8><?php echo e(substr($u->profil, 0, 100)); ?> . . .</h6>
          </div>
          <div class="widget-user-image" style="margin-top: -55px; text-align: right; right:20px;">
            <img class="img-square" src="<?php echo e(url($u->logo_ukm)); ?>" alt="User Avatar" style="width: 100px; height: 100px;">
          </div>
          <div class="box-footer" style="margin:0px;">
            <div class="row">
              <div class="col-sm-12">
                <div class="description-block" style="text-align: right;">
                    <h5 class="description-header" style="margin-top: -25px;">
                      <a class="btn btn-sm btn-danger" data-toggle="modal" data-target="#modal-danger<?php echo e($u->id); ?>">
                        Hapus Ukm <i class="fa fa-trash"></i>
                      </a>
                      <a href="<?php echo e(route('profilUkm.index', $u->id)); ?>" class="btn btn-sm btn-success">
                        Info Lengkap  <i class="fa fa-arrow-circle-right"></i>
                      </a>
                    </h5>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- modal konfirmasi hapus -->
      <div class="modal modal-danger fade" id="modal-danger<?php echo e($u->id); ?>">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span></button>
              <h4 class="modal-title">Konfirmasi</h4>
            </div>
            <div class="modal-body">
              <p>Anda yakin akan menghapus Ukm <?php echo e($u->nama_ukm); ?> ?</p>
            </div>
            <div class="modal-footer">
              <!-- <button type="button" class="btn btn-outline pull-left" data-dismiss="modal">Close</button> -->
              <form action="<?php echo e(route('profilUkm.destroy', $u->id)); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('DELETE')); ?>

                        <button type="submit" class="btn btn-outline">Ya</button>
              </form>
              <button type="button" data-dismiss="modal" class="btn btn-outline">Tidak</button>
            </div>
          </div>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      <div class="col-md-4">
        <div class="box box-widget widget-user">
          <!-- Add the bg color to the header using any of the bg-* classes -->
          <div class="widget-user-header" style="background: #009ABF; color:white;">
            <h3 class="widget-user-username" style="font-size: 12pt;"><b><b></h3>
            <h6 class=col-md-8></h6>
          </div>
          <div class="widget-user-image" style="margin-top: -55px; text-align: right;">
            <i class="fa fa-plus-circle" style="font-size:100px; color:white;"></i>
          </div>
          <div class="box-footer">
            <div class="row">
              <div class="col-sm-12">
                <div class="description-block" style="text-align: right; margin-top: -15px;">
                  <a href="<?php echo e(route('profilUkm.create')); ?>" class="btn btn-sm btn-primary">
                    Tambah Ukm Baru <i class="fa fa-plus"></i>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>


    </div>
  </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>